package com.example.food_delivery.dto.domain;

public record LoginUserResponseDto(
        String token
) {
}
