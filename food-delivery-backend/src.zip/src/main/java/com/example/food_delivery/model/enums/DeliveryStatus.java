package com.example.food_delivery.model.enums;

public enum DeliveryStatus {
    ASSIGNED,
    PICKED_UP,
    EN_ROUTE,
    DELIVERED,
    CANCELED
}
