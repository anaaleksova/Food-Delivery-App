package com.example.food_delivery.model.enums;

public enum PaymentStatus {
    REQUIRES_ACTION,
    AUTHORIZED,
    CAPTURED,
    FAILED
}
