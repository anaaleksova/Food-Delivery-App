package com.example.food_delivery.dto.domain;

public record LoginUserRequestDto(
        String username,
        String password
) {
}
