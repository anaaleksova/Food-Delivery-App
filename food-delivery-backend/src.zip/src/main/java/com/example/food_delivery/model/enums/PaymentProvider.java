package com.example.food_delivery.model.enums;

public enum PaymentProvider {
    STRIPE //vaka moze da kazeme dokolku se dodadat i drugi lesno bi se implementiralo namesto from start
}
